package com.example.clase7

object NavRoutes {
    const val USERS = "users"
    const val FORM = "users_form"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val SUCCESS = "logSuccess"
}